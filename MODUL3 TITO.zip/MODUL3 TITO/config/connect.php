<?php
    $localhost = 'localhost:3306';
    $mysql_user = 'root';
    $mysql_password = '';
    $nama_database = 'tito_table';

    $connect = mysqli_connect($localhost, $mysql_user, $mysql_password, $nama_database);

?>